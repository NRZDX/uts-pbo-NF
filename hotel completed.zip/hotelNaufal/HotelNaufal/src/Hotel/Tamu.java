package Hotel;

import java.util.ArrayList;
import java.util.List;

class Tamu {
    private String nama;
    private String nomorIdentitas;
    private String kontak;
    private List<Reservasi> daftarReservasi;

    public Tamu(String nama, String nomorIdentitas, String kontak) {
        this.nama = nama;
        this.nomorIdentitas = nomorIdentitas;
        this.kontak = kontak;
        this.daftarReservasi = new ArrayList<>();
    }

    public void tampilkanInfoTamu() {
        System.out.println("Nama: " + nama);
        System.out.println("Nomor Identitas: " + nomorIdentitas);
        System.out.println("Kontak: " + kontak);
        System.out.println("Reservasi Aktif: " + daftarReservasi.size());
        System.out.println("---------------------");
    }

    public void tambahReservasi(Reservasi reservasi) {
        daftarReservasi.add(reservasi);
    }

    public List<Reservasi> getDaftarReservasi() {
        return daftarReservasi;
    }

    public String getNama() {
        return nama;
    }

    @Override
    public String toString() {
        return nama; // Return the name for better display in reservations
    }
}
package Hotel;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

class Reservasi {
    private Tamu tamu;
    private Kamar kamar;
    private LocalDate tanggalCheckIn;
    private LocalDate tanggalCheckOut;
    private int durasiMenginap;
    private boolean aktif;

    public Reservasi(Tamu tamu, Kamar kamar, LocalDate tanggalCheckIn, LocalDate tanggalCheckOut) {
        this.tamu = tamu;
        this.kamar = kamar;
        this.tanggalCheckIn = tanggalCheckIn;
        this.tanggalCheckOut = tanggalCheckOut;
        this.durasiMenginap = (int) ChronoUnit.DAYS.between(tanggalCheckIn, tanggalCheckOut);
        this.aktif = true;
    }

    public void tampilkanInfoReservasi() {
        System.out.println("Tamu: " + tamu);
        System.out.println("Kamar: " + kamar);
        System.out.println("Tanggal Check-In: " + tanggalCheckIn);
        System.out.println("Tanggal Check-Out: " + tanggalCheckOut);
        System.out.println("Durasi Menginap: " + durasiMenginap + " malam");
        System.out.println("Status: " + (aktif ? "Aktif" : "Dibatalkan"));
        System.out.println("---------------------");
    }

    public void batalkan() {
        this.aktif = false;
        kamar.setTersedia(true);
    }

    public boolean isAktif() {
        return aktif;
    }

    public Kamar getKamar() {
        return kamar;
    }
}
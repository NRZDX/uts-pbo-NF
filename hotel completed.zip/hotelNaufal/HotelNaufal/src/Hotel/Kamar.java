package Hotel;

class Kamar {
    private int nomorKamar;
    private String tipeKamar;
    private double hargaPerMalam;
    private boolean tersedia;

    public Kamar(int nomorKamar, String tipeKamar, double hargaPerMalam) {
        this.nomorKamar = nomorKamar;
        this.tipeKamar = tipeKamar;
        this.hargaPerMalam = hargaPerMalam;
        this.tersedia = true;
    }

    public void tampilkanInfoKamar() {
        System.out.println("Nomor Kamar: " + nomorKamar);
        System.out.println("Tipe Kamar: " + tipeKamar);
        System.out.println("Harga per Malam: Rp" + hargaPerMalam);
        System.out.println("Status: " + (tersedia ? "Tersedia" : "Dipesan"));
        System.out.println("---------------------");
    }

    public double getHargaPerMalam() {
        return hargaPerMalam;
    }

    public int getNomorKamar() {
        return nomorKamar;
    }

    public boolean isTersedia() {
        return tersedia;
    }

    public void setTersedia(boolean tersedia) {
        this.tersedia = tersedia;
    }

    @Override
    public String toString() {
        return "Kamar " + nomorKamar + " (" + tipeKamar + ")";
    }
}
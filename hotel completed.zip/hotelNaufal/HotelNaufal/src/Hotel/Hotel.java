package Hotel;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

class Hotel {
    private List<Kamar> daftarKamar;
    private List<Tamu> daftarTamu;
    private List<Reservasi> daftarReservasi;

    public Hotel() {
        daftarKamar = new ArrayList<>();
        daftarTamu = new ArrayList<>();
        daftarReservasi = new ArrayList<>();
    }

    public void tambahKamar(Kamar kamar) {
        daftarKamar.add(kamar);
    }

    public void tambahTamu(Tamu tamu) {
        daftarTamu.add(tamu);
    }

    public void buatReservasi(Tamu tamu, Kamar kamar, LocalDate checkIn, LocalDate checkOut) {
        if (kamar.isTersedia()) {
            Reservasi reservasi = new Reservasi(tamu, kamar, checkIn, checkOut);
            daftarReservasi.add(reservasi);
            tamu.tambahReservasi(reservasi);
            kamar.setTersedia(false);
        } else {
            System.out.println("Kamar tidak tersedia untuk reservasi.");
        }
    }

    public void batalkanReservasi(Reservasi reservasi) {
        if (reservasi.isAktif()) {
            reservasi.batalkan();
            System.out.println("Reservasi dibatalkan.");
        } else {
            System.out.println("Reservasi sudah dibatalkan sebelumnya.");
        }
    }

    public List<Kamar> daftarKamarTersedia() {
        List<Kamar> kamarTersedia = new ArrayList<>();
        for (Kamar kamar : daftarKamar) {
            if (kamar.isTersedia()) {
                kamarTersedia.add(kamar);
            }
        }
        return kamarTersedia;
    }

    public List<Tamu> getDaftarTamu() {
        return daftarTamu;
    }

    public List<Kamar> getDaftarKamar() {
        return daftarKamar;
    }

    public List<Reservasi> getDaftarReservasi() {
        return daftarReservasi;
    }
}
package Hotel;

import java.util.List;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        Hotel hotel = new Hotel();
        Scanner scanner = new Scanner(System.in);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        
        System.out.println("=========================================");
        System.out.println("TUGAS PEMROGRAMAN BERORIENTASI OBJEK");
        System.out.println("TEMA TUGAS: HOTEL (B)");
        System.out.println("NAMA\t: Naufal Fairuzaj");
        System.out.println("NIM\t: 32602300034");
        System.out.println("=========================================");
        System.out.println();

        while (true) {
            System.out.println("=--=--= Menu Hotel Cemara =--=--=");
            System.out.println("1. Tambah Kamar");
            System.out.println("2. Daftar Kamar Tersedia");
            System.out.println("3. Daftar Tamu Baru");
            System.out.println("4. Buat Reservasi");
            System.out.println("5. Batalkan / Hapus Reservasi");
            System.out.println("6. Daftar Tamu dan Reservasi");
            System.out.println("7. Informasi Tipe Kamar");
            System.out.println("8. Keluar");
            System.out.print("Pilih opsi: ");
            int pilihan = scanner.nextInt();
            scanner.nextLine();

            switch (pilihan) {
            case 1:
                System.out.print("Masukkan Nomor Kamar: ");
                int nomorKamar = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Masukkan Tipe Kamar (Single/Double/Deluxe): ");
                String tipeKamar = scanner.nextLine();
                System.out.print("Masukkan Harga per Malam: ");
                double hargaPerMalam = scanner.nextDouble();

                if (tipeKamar.equalsIgnoreCase("Deluxe")) {
                    System.out.print("Apakah termasuk sarapan? (true/false): ");
                    boolean fasilitasSarapan = scanner.nextBoolean();
                    Kamar kamarBaru = new KamarDeluxe(nomorKamar, hargaPerMalam, fasilitasSarapan);
                    hotel.tambahKamar(kamarBaru);
                } else {
                    Kamar kamarBaru = new Kamar(nomorKamar, tipeKamar, hargaPerMalam);
                    hotel.tambahKamar(kamarBaru);
                }
                System.out.println("Kamar berhasil ditambahkan.\n");
                break;


                case 2:
                    List<Kamar> kamarTersedia = hotel.daftarKamarTersedia();
                    if (kamarTersedia.isEmpty()) {
                        System.out.println("\nTidak ada kamar yang tersedia.");
                    } else {
                        System.out.println("\nKamar Tersedia:");
                        for (Kamar kamar : kamarTersedia) {
                            kamar.tampilkanInfoKamar();
                        }
                    }
                    break;

                case 3:
                    System.out.print("Masukkan Nama Tamu: ");
                    String nama = scanner.nextLine();
                    System.out.print("Masukkan Nomor Identitas: ");
                    String nomorIdentitas = scanner.nextLine();
                    System.out.print("Masukkan Kontak: ");
                    String kontak = scanner.nextLine();
                    Tamu tamuBaru = new Tamu(nama, nomorIdentitas, kontak);
                    hotel.tambahTamu(tamuBaru);
                    System.out.println("Tamu berhasil ditambahkan.");
                    System.out.println();
                    break;

                case 4:
                    System.out.print("Masukkan Nama Tamu: ");
                    String namaTamuReservasi = scanner.nextLine();
                    Tamu tamuReservasi = null;
                    for (Tamu tamu : hotel.getDaftarTamu()) {
                        if (tamu.getNama().equalsIgnoreCase(namaTamuReservasi)) {
                            tamuReservasi = tamu;
                            break;
                        }
                    }
                    if (tamuReservasi == null) {
                        System.out.println("Tamu tidak ditemukan.");
                        System.out.println();
                        break;
                    }

                    System.out.print("Masukkan Nomor Kamar: ");
                    int nomorKamarReservasi = scanner.nextInt();
                    scanner.nextLine();
                    Kamar kamarReservasi = null;
                    for (Kamar kamar : hotel.getDaftarKamar()) {
                        if (kamar.getNomorKamar() == nomorKamarReservasi) {
                            kamarReservasi = kamar;
                            break;
                        }
                    }
                    if (kamarReservasi == null || !kamarReservasi.isTersedia()) {
                        System.out.println("Kamar tidak tersedia.");
                        System.out.println();
                        break;
                    }

                    System.out.print("Masukkan Tanggal Check-In (yyyy-MM-dd): ");
                    LocalDate checkIn = LocalDate.parse(scanner.nextLine(), formatter);
                    System.out.print("Masukkan Tanggal Check-Out (yyyy-MM-dd): ");
                    LocalDate checkOut = LocalDate.parse(scanner.nextLine(), formatter);
                    
                    hotel.buatReservasi(tamuReservasi, kamarReservasi, checkIn, checkOut);
                    System.out.println("Reservasi berhasil dibuat.");
                    System.out.println();
                    break;

                case 5:
                    System.out.print("Masukkan Nama Tamu: ");
                    String namaTamuBatalkan = scanner.nextLine();
                    Tamu tamuBatalkan = null;
                    for (Tamu tamu : hotel.getDaftarTamu()) {
                        if (tamu.getNama().equalsIgnoreCase(namaTamuBatalkan)) {
                            tamuBatalkan = tamu;
                            break;
                        }
                    }
                    if (tamuBatalkan == null) {
                        System.out.println("Tamu tidak ditemukan.");
                        break;
                    }

                    System.out.print("Masukkan Nomor Kamar: ");
                    int nomorKamarBatalkan = scanner.nextInt();
                    scanner.nextLine();
                    Reservasi reservasiDibatalkan = null;
                    for (Reservasi reservasi : tamuBatalkan.getDaftarReservasi()) {
                        if (reservasi.getKamar().getNomorKamar() == nomorKamarBatalkan && reservasi.isAktif()) {
                            reservasiDibatalkan = reservasi;
                            break;
                        }
                    }
                    if (reservasiDibatalkan == null) {
                        System.out.println("Reservasi tidak ditemukan atau sudah dibatalkan.");
                        break;
                    }

                    hotel.batalkanReservasi(reservasiDibatalkan);
                    System.out.println("Reservasi berhasil dibatalkan.");
                    System.out.println();
                    break;

                case 6:
                    System.out.println("\n=--=--=--=--=--=--=--=--=--=--=--=");
                    System.out.println("Daftar Tamu:");
                    Set<String> tamuDitampilkan = new HashSet<>();
                    for (Tamu tamu : hotel.getDaftarTamu()) {
                        if (!tamuDitampilkan.contains(tamu.getNama())) {
                            tamu.tampilkanInfoTamu();
                            tamuDitampilkan.add(tamu.getNama());
                        }

                        boolean adaReservasiAktif = false;
                        for (Reservasi reservasi : tamu.getDaftarReservasi()) {
                            if (reservasi.isAktif()) {
                                adaReservasiAktif = true;
                                reservasi.tampilkanInfoReservasi();
                            }
                        }

                        if (!adaReservasiAktif) {
                            System.out.println("Tidak ada reservasi aktif.");
                        }
                        System.out.println();
                    }
                    break;
                    
                case 7:
                    System.out.println("\nInformasi Tipe Kamar:\n");
                    System.out.println("Single: kamar ini cukup sempit, berisi 1 kasur, AC, TV, \nkamar mandi dalam beserta peralatan mandi, lemari, dan peralatan seduh teh dan kopi.\n");
                    System.out.println("Double: kamar ini cukup luas, berisi 2 kasur, AC, TV, \nkamar mandi dalam beserta peralatan mandi, lemari, dan peralatan seduh teh dan kopi.\n");
                    System.out.println("Deluxe: kamar ini sangat luas, berisi 1 kasur untuk 2 orang, AC, TV, \nkamar mandi dalam beserta peralatan mandi, lemari, peralatan seduh teh dan kopi, dan akses sarapan di lantai dasar.");
                    System.out.println();
                    break;


                case 8:
                    System.out.println("Terima kasih! Sampai jumpa.");
                    scanner.close();
                    return;

                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        }
    }
}
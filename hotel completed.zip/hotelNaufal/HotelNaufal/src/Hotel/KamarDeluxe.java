package Hotel;

public class KamarDeluxe extends Kamar {
    private boolean fasilitasSarapan;

    public KamarDeluxe(int nomorKamar, double hargaPerMalam, boolean fasilitasSarapan) {
        super(nomorKamar, "Deluxe", hargaPerMalam);
        this.fasilitasSarapan = fasilitasSarapan;
    }

    public boolean isFasilitasSarapan() {
        return fasilitasSarapan;
    }

    @Override
    public void tampilkanInfoKamar() {
        super.tampilkanInfoKamar();
        System.out.println("Fasilitas Sarapan: " + (fasilitasSarapan ? "Ya" : "Tidak"));
    }
}
